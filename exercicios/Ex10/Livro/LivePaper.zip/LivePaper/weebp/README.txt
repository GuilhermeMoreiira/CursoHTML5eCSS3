Version: weebp-0.6.1-windows-x64
Source: https://github.com/Francesco149/weebp

Files:
 		- wp.exe
 		- wp-headless.exe
 		- weebp.lib
 		- weebp.dll
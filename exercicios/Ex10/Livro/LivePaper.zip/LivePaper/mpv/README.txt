Version: mpv-x86_64-20181002
Source: https://github.com/mpv-player/mpv

Files:
 		- mpv.exe
 		- mpv.com
 		- libbdplus.dll
 		- libaacs.dll
 		- mpv.conf
